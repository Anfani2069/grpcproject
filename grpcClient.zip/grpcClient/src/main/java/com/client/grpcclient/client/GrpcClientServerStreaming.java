package com.client.grpcclient.client;

import com.client.grpcclient.stubs.BankServiceGrpc;
import com.client.grpcclient.stubs.Ebank;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.stub.StreamObserver;
import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

@Slf4j
public class GrpcClientServerStreaming {
    public static void main(String[] args) throws IOException {

    ManagedChannel managedChannel= ManagedChannelBuilder.forAddress("localhost",8080)
            .usePlaintext()
            .build();
    BankServiceGrpc.BankServiceStub asyncStub= BankServiceGrpc.newStub(managedChannel);
    Ebank.ConvertCurrencyRequest request= Ebank.ConvertCurrencyRequest.newBuilder()
            .setAmount(8600)
            .setCurrencyFrom("MAD")
            .setCurrencyTo("EUR")
            .build();

    asyncStub.convert(request, new StreamObserver<Ebank.ConvertCurrencyReponse>() {
        @Override
        public void onNext(Ebank.ConvertCurrencyReponse convertCurrencyReponse) {

           // System.out.println(convertCurrencyReponse);
            ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
            Runnable task = () -> {
                System.out.println("Tache executé");
            };

            scheduler.scheduleAtFixedRate(task, 0, 3, TimeUnit.SECONDS);

        }

        @Override
        public void onError(Throwable throwable) {
            System.out.println(throwable.getMessage());
        }

        @Override
        public void onCompleted() {
           // System.out.println("END .....");
        }
    });

    System.in.read();
}
}

