package com.client.grpcclient.client;

import com.client.grpcclient.stubs.BankServiceGrpc;
import com.client.grpcclient.stubs.Ebank;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import lombok.extern.slf4j.Slf4j;


import java.io.IOException;

@Slf4j
public class GrpcClient {
    public static void main(String[] args) throws IOException {
    ManagedChannel managedChannel= ManagedChannelBuilder.forAddress("localhost",8080)
            .usePlaintext()
            .build();
    BankServiceGrpc.BankServiceBlockingStub blockingStub= BankServiceGrpc.newBlockingStub(managedChannel);
    Ebank.ConvertCurrencyRequest request= Ebank.ConvertCurrencyRequest.newBuilder()
            .setAmount(8600)
            .setCurrencyFrom("MAD")
            .setCurrencyTo("EUR")
            .build();
        //le blockingStub pour unary model
    Ebank.ConvertCurrencyReponse response = blockingStub.convert(request);
        System.out.println(response);
}
}

