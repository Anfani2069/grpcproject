package com.client.grpcclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrpcClientApplicationTests {

    @Test
    void contextLoads() {
    }

}
