package com.grpcproject.grpc.service;

import com.grpcproject.grpc.stubs.BankServiceGrpc;
import com.grpcproject.grpc.stubs.Ebank;
import io.grpc.stub.StreamObserver;

public class BankGrpcService extends BankServiceGrpc.BankServiceImplBase {
    @Override
    public void convert(Ebank.ConvertCurrencyRequest request, StreamObserver<Ebank.ConvertCurrencyReponse> responseObserver) {
       String currencyFrom = request.getCurrencyFrom();
       String currencyTo = request.getCurrencyTo();
       Float amount = request.getAmount();

       // Envoie des reponses

        Ebank.ConvertCurrencyReponse reponse = Ebank.ConvertCurrencyReponse.newBuilder()
                .setCurrencyFrom(currencyFrom)
                .setCurrencyTo(currencyTo)
                .setAmount(amount)
                .setResult(amount*10)
                .build();

        responseObserver.onNext(reponse);
        responseObserver.onCompleted();

    }

    @Override
    public void getStream(Ebank.ConvertCurrencyRequest request, StreamObserver<Ebank.ConvertCurrencyReponse> responseObserver) {
        super.getStream(request, responseObserver);
    }

    @Override
    public StreamObserver<Ebank.ConvertCurrencyRequest> performStream(StreamObserver<Ebank.ConvertCurrencyReponse> responseObserver) {
        return super.performStream(responseObserver);
    }

    @Override
    public StreamObserver<Ebank.ConvertCurrencyRequest> fullCurrencyStream(StreamObserver<Ebank.ConvertCurrencyReponse> responseObserver) {
        return super.fullCurrencyStream(responseObserver);
    }
}
