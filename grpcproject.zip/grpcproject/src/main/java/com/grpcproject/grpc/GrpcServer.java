package com.grpcproject.grpc;

import com.grpcproject.grpc.service.BankGrpcService;
import io.grpc.Server;
import io.grpc.ServerBuilder;


import java.io.IOException;
import java.util.logging.Logger;


public class GrpcServer {
    public static void main(String[] args) throws InterruptedException, IOException {

        Logger logger = Logger.getLogger("My logger : ");

        Server server = ServerBuilder.forPort(8080)
                .addService(new BankGrpcService())
                .build();
        server.start();
        logger.info("Server starting");
        server.awaitTermination();

    }
}
